var data = {
  'perso_0' : {
    'name' : 'Chouwi',
    'picture' : 'https://s-media-cache-ak0.pinimg.com/236x/29/73/b1/2973b1e486b022a664e570f40d67e0da.jpg',
    'texte' : ['Brouuuuwhaaaaa','Drrrriiiitch','Hinnn Wouaaa']
  },
  'perso_1' : {
    'name' : 'Archibalde',
    'picture' : 'https://s-media-cache-ak0.pinimg.com/originals/00/37/03/0037037f1590875493f413c1fdbd52b1.jpg',
    'texte' : ['Grand père, c\'est moi!','J\'aime les pâttes moi aussi','Pff nimporte quoi!']
  }
}
