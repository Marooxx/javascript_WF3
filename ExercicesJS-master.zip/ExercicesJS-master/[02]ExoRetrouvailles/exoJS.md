# Le dialogue

dans cet exercice
