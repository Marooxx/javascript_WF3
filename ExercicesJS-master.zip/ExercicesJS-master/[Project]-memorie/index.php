<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/style.css">
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<div class="table" id="table"></div>
		<script src="js/jeu.js"></script>
	<script src="js/main.js"></script>
</body>
</html>