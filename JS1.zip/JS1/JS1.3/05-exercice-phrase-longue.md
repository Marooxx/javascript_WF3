## Enoncé

Rechercher et afficher en HTML la chaîne ayant le plus grand nombre de caractères dans le tableau de phrases.

## Remarques

* Le programme doit etre dynamique : le tableau peut s'aggrandir ou diminuer sans qu'il y ait besoin de modifier le code.
* Les tableaux comme les chaînes de caractères sont des objets et disposent chacun d'une propriété nécessaire pour le programme.
* Construire par étapes le programme : faire une boucle, puis une boucle qui affiche la longueur de chaque phrase, etc.
* A la fin il faut afficher la phrase la plus longue elle-même ainsi que sa longueur.