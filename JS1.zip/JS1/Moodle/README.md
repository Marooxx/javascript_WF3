### Module JavaScript niveau 1

Apprentissage de la programmation procédurale avec le langage JavaScript dans les navigateurs web.

Supports et contenus supplémentaires :

- <a href="http://devdocs.io/javascript/" target="_blank">DevDocs - Référence JavaScript</a>
- <a href="https://openclassrooms.com/courses/apprenez-a-coder-avec-javascript" target="_blank">OpenClassrooms - Apprenez à coder avec JavaScript</a>

---