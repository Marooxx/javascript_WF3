## Enoncé

L'utilisateur saisit un montant HT et peut saisir s'il le souhaite une remise, le résultat TTC s'affiche en HTML.

## Détails

* L'utilisateur doit pouvoir répondre oui ou yes à la demande de remise.
* La saisie de la remise se fait en pourcentage, un nombre à virgule donc, et elle s'applique sur le montant HT autrement il y a fraude à la TVA ;-)
* Au moment de l'affichage on doit connaître le pourcentage de remise, s'il y en a eu une, ou bien savoir le fait qu'aucune remise n'a été appliquée.
* Il faut répéter le moins de code possible, notamment il ne faut pas répéter le calcul du montant TTC final.