## Enoncé

L'utilisateur choisit pierre, feuille ou ciseau, l'ordinateur choisit aléatoirement l'une des trois possibilités, et la partie commence !

## Détails

* On doit pouvoir indifféremment saisir le mot en minuscules comme en majuscules.
* Le ciseau est écrasé par la pierre.
* La feuille est découpée par le ciseau.
* La pierre est enveloppée par la feuille.
* Si le joueur et l'ordinateur font le même choix on obtient une égalité.