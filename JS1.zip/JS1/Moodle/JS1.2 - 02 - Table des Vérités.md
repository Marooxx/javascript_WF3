***

> Plusieurs comparaisons booléennes peuvent être combinées avec un **ET** ou un **OU** logique. On appelle cela de l'algèbre booléen.

***