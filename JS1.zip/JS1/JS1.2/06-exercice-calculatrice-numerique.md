## Enoncé

L'utilisateur saisit un nombre puis un autre ainsi que l'opération mathématique souhaitée, le résultat s'affiche en HTML.

## Remarques

* Les nombres saisis peuvent être à virgule.
* La calculatrice doit accepter les quatres opérations mathématiques de base et rejeter toutes les autres.
* L'utilisateur doit pouvoir autant saisir le nom de l'opération que l'opérateur correspondant : + - * /
* La division par zéro n'existe pas, il va falloir gérer ce cas…
* Il faut répéter le moins de code possible, notamment le code d'affichage du résultat