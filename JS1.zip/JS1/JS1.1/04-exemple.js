/*
 * Nous sommes ici directement en JavaScript, aucune balise <script> n'est nécessaire !
 *
 * Exactement comme pour les fichiers .css de feuilles de styles
 */

document.write('<p>Bonjour tout le monde !</p>');

window.alert('Bonjour tout le monde !');

console.log('Bonjour tout le monde !');