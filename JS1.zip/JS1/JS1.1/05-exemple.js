// Déclaration d'une variable.
var uneVariable;


// Affectation d'une valeur à la variable.
uneVariable = 'Bonjour tout le monde !';

// Affichage du contenu de la variable directement dans la page HTML.
document.write(uneVariable);

var prenom;
prenom = 'Caroline';
prenom = 'Fred';

alert(prenom);