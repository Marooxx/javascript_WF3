## Enoncé

Afficher dynamiquement la date d'aujourd'hui en HTML sous la forme “Nous sommes le Mardi 11 Février 2014”.

## Ressources

* [Classe Date dans DevDocs.io](http://devdocs.io/javascript/global_objects/date)

## Remarques

* Il va falloir se servir de tableaux pour afficher les noms des jours de la semaine et des mois...
* Bien lire la documentation sur les différentes méthodes et en particulier les valeurs renvoyées