### Module JavaScript niveau 1

Apprentissage de la programmation procédurale avec le langage JavaScript dans les navigateurs web.

Supports et contenus supplémentaires :

- [DevDocs - Référence JavaScript](http://devdocs.io/javascript/)
- [OpenClassrooms - Apprenez à coder avec JavaScript](https://openclassrooms.com/courses/apprenez-a-coder-avec-javascript)

---